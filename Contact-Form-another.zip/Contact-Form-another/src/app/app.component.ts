import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
    name='foo';
    title = 'Contact-Form-Another';
    btnHeight = 50;
    btnWidth = 50;
    FormData: FormGroup;
    product={name: 'Dell Laptop',
      price: 500
    };
    constructor(private builder: FormBuilder) { }

  ngOnInit(http:HttpClient) {
    this.FormData = this.builder.group({
      Name: new FormControl('', [Validators.required]),
      Score: new FormControl('', [Validators.compose([Validators.required, Validators.email])]),
      Attendance: new FormControl('', [Validators.required]),
      Grade: new FormControl('', [Validators.required])
    });
  }


  onSubmit(FormData) {
    console.log(FormData);
    console.log('onSubmit-FormData');
    console.log('onSubmit-add product');
    console.log('onSubmit-check via browser console');
  }
  addProduct() {
    console.log('addProduct-add product');
    console.log('addProduct-check via browser console');
  }
}

